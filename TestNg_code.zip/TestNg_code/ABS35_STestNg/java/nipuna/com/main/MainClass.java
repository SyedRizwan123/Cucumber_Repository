package nipuna.com.main;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

	
public class MainClass {
	public static WebDriver driver;
	public String url = "https://www.amazon.in/";
	public String url2 = "https://login.salesforce.com/?local=in";	
  @BeforeMethod
  public void LaunchAut() {
	  driver = new ChromeDriver();
	  //driver.get("https://www.amazon.in/");
	  driver.get(url2);
	  driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	  driver.manage().window().maximize();
  }
  
  @AfterMethod
  public void Close() throws Exception
  {
	  Thread.sleep(3000);
	  driver.quit();
  }
  
}
