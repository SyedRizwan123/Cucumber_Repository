package nipuna.com.common;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import nipuna.com.scripts.Salesforce_login;

public class Sales_Force_Login extends Salesforce_login {
	
	static By uname = By.id("username"); //we are able to provide static directly we can call variable inside of the Sales_Login method
	static By pws = By.id("password");
	static By login = By.id("Login");
	
	@Test
	public static void Sales_Login()
	{
		driver.findElement(uname).sendKeys("anilkumartesting11@gmail.com");
		driver.findElement(pws).sendKeys("sfvbfjh");
		driver.findElement(login).click();
	}

}
