package nipuna.com.common;

import org.openqa.selenium.By;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import nipuna.com.main.MainClass;

public class Data_Provider extends MainClass {
  //Locators
	static By uname = By.id("username");
	static By pwd =By.id("password");
	static By login = By.id("login");
	
  @Test (dataProvider = "logindata")
  public void senddata(String username, String password) {
	  driver.findElement(uname).sendKeys(username);
	  driver.findElement(pwd).sendKeys(password);
	  driver.findElement(login).click();
  }
  
  @DataProvider(name = "logindata")
  public Object[][] logindata(){
  	
	  Object[][] data = new Object[2][2];   //inside of the brackets we have to give sizes
  	  data[0][0] = "Syedrizwan22@gmail.com";
  	  data[0][1] = "avchjvc";
  	  data[1][0] = "Rizwansyed22@gmail.com";
  	  data[1][1] = "dfsjvh";
  	  return data;
}
}
