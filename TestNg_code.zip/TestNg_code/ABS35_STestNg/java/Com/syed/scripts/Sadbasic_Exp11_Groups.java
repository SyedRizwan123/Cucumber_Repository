package Com.syed.scripts;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Sadbasic_Exp11_Groups {

	
	@Test (groups = "Retesting")
	public void LaunchAUT() {
		  System.out.println(" Launch Application");
	}
	@Test (groups = {"Regrassion", "smokey"})
	public void SendData() {
		  System.out.println("Sent the data");
	} 
	@Test (priority = 0, enabled =false)
	public void Login() {
		  System.out.println("Login the Application");
	}
	
	
	@Test (priority = 0, description = "This is a send data")
	public void Logout() {
		  System.out.println("Logout Succesfully");
	}
	}
