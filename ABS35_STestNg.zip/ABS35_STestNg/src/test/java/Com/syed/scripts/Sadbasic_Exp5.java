package Com.syed.scripts;


import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Sadbasic_Exp5 {
	 @BeforeClass   //it is a common method.
	  public void LaunchAUT() {
		  System.out.println("Launch Application");
	  }
	  @Test
	  public void SendData() {
		  System.out.println("Sent the data");
	  }
	  @Test
	  public void Login() {
		  System.out.println("Login the Application");
	  }
	  @AfterClass
	  public void Logout() {
		  System.out.println("Logout Succesfully");
	  }
	}

