package Com.syed.scripts;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Sadbasic_Exp9 {
  //@BeforeClass
	@AfterClass
  public void LaunchAUT() {
	  System.out.println(" Launch Application");
  }
  //@AfterTest
	@BeforeTest
  public void SendData() {
	  System.out.println("Sent the data");
  } 
  @Test (priority = 0)
  public void Login() {
	  System.out.println("Login the Application");
  }
  @Test (priority = 1)
  public void Logout() {
	  System.out.println("Logout Succesfully");
  }
}
