package Com.syed.scripts;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

//How to Skip TestCases
public class Sadbasic_Exp8 {
	 @BeforeMethod  
	  public void LaunchAUT() {
		  System.out.println(" Launch Application");
	  }
	  @Test (priority = -1)
	  public void SendData() {
		  System.out.println("Sent the data");
	  } 
	  @Test (priority = 0)
	  public void Login() {
		  System.out.println("Login the Application");
	  }
	  @Test (priority = 1)
	  public void Logout() {
		  System.out.println("Logout Succesfully");
	  }
	}

