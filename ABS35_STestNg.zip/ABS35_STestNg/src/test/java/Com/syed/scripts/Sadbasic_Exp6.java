package Com.syed.scripts;


import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Sadbasic_Exp6 {
	 @BeforeTest  
	  public void LaunchAUT() {
		  System.out.println("Launch Application");
	  }
	  @BeforeMethod
	  public void SendData() {
		  System.out.println("Sent the data");
	  }
	  @AfterTest
	  public void Login() {
		  System.out.println("Login the Application");
	  }
	  @Test
	  public void Logout() {
		  System.out.println("Logout Succesfully");
	  }
	}

