package nipuna.com.common;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import nipuna.com.scripts.Amazon_script1;

public class Amazon_Common extends Amazon_script1 {
	static By Searchbar = By.id("twotabsearchtextbox");
	static By Searchicon = By.id("nav-search-submit-text");
@Test
public static void senddata() {
	driver.findElement(Searchbar).sendKeys("Java");
	driver.findElement(Searchicon).click();
}

}
