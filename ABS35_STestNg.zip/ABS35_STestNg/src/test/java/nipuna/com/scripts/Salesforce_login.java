package nipuna.com.scripts;

import org.testng.annotations.Test;

import nipuna.com.common.Sales_Force_Login;
import nipuna.com.main.MainClass;

public class Salesforce_login extends MainClass {

	@Test
	public void Sales_login() {
		Sales_Force_Login.Sales_Login();
	}
}