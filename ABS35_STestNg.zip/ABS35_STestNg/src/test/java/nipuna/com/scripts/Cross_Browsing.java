package nipuna.com.scripts;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import nipuna.com.common.Sales_Force_Login;


public class Cross_Browsing
{
	//Global: Global is instance variable
  WebDriver driver;
  @BeforeClass
  @Parameters("browsers")
  
  public void Cross(String browsers)  {
	  switch (browsers.toLowerCase())
	  {
	  case "chrome":
		  	System.setProperty("webdriver.chrome.driver","C:\\Users\\DELL\\Downloads\\chromedriver-win64\\chromedriver.exe");
	  		driver = new ChromeDriver();
	  		driver.get("https://login.salesforce.com/?locale=in");
	  		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	  		driver.manage().window().maximize();
	  		break;
	  case "fire":
		  	System.setProperty("webdriver.gecko.driver","C:\\Users\\DELL\\Downloads\\geckodriver-v0.35.0-win64\\geckodriver.exe");
	  		driver = new FirefoxDriver();
	  		driver.get("https://www.amazon.in/");
	  		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	  		driver.manage().window().maximize();
	  		break;
	  case "Edge":
		  	System.setProperty("webdriver.edge.driver","C:\\Users\\DELL\\Downloads\\edgedriver_win64\\msedgedriver.exe");
	  		driver = new FirefoxDriver();
	  		driver.get("https://www.flipkart.com/");
	  		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	  		driver.manage().window().maximize();
	  		break;
	  		default:
	  			driver = null;
	  }
	  
  }
  
  @Test (priority = 0)
  public void senddata() 
  {
	    driver.findElement(By.id("username")).sendKeys("anilkumartesting11@gmail.com");
		driver.findElement(By.id("password")).sendKeys("sfvbfjh");
		driver.findElement(By.id("Login")).click();
		
		driver.quit();
  }
}
