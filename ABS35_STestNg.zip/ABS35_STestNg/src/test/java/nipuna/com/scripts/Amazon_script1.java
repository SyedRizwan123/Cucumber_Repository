package nipuna.com.scripts;

import org.testng.annotations.Test;

import nipuna.com.common.Amazon_Common;
import nipuna.com.main.MainClass;

public class Amazon_script1 extends MainClass{
	@Test
	public void Amazon_Script() {
		Amazon_Common.senddata();
	}
}
