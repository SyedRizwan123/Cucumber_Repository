package Step_Defination;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
		//features="C:\\Users\\HP\\Desktop\\Eclipse\\ABS9_SCucumber\\src\\test\\resources\\Feature\\login_sale.feature",
		//features="C:\\Users\\HP\\Desktop\\Eclipse\\ABS9_SCucumber\\src\\test\\resources\\Feature\\amazonSeacrh.feature",
		//features="C:\\Users\\HP\\Desktop\\Eclipse\\ABS9_SCucumber\\src\\test\\resources\\Feature\\amazonValidate.feature",
		//features="C:\\Users\\HP\\Desktop\\Eclipse\\ABS9_SCucumber\\src\\test\\resources\\Feature\\sale_f.feature",
		features="C:\\Users\\HP\\Desktop\\Eclipse\\ABS9_SCucumber\\src\\test\\resources\\Feature\\typesoftesting.feature",
		
		glue = {"Step_Defination"},   //here we need to provide Step_Defination package name
		tags= "@Retesting"
		//plugin = {"pretty", "html:target/cucumber-reports.html"}
		)

public class TestRunner {
}
