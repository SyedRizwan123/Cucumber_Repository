package Step_Defination;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefination {
	WebDriver driver = new ChromeDriver();
	//@Given("launch the salesforce application")
	
	
	static By s_bar=By.id("twotabsearchtextbox");
	static By Icon=By.id("nav-search-submit-button");
	static By mobile = By.xpath("//a[text()='Mobiles']");
	static By sell = By.xpath("//a[text()='Sell']");
	@Given("Launch the Application")
	
	
	public void launch_the_salesforce_application() {
	    driver.manage().window().maximize();
	    driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		//driver.get("https://login.salesforce.com/?locale=in");
	    //driver.get("https://www.amazon.in/");
	    //driver.get("https://login.salesforce.com/?locale=in");
	    driver.get("https://www.amazon.in");
	}

	@When("user need to enter uname and pwd")
	public void user_need_to_enter_uname_and_pwd() throws Exception 
	{
	   driver.findElement(By.id("username")).sendKeys("SyedRizwanTesting@gmail.com");
	   Thread.sleep(2000);
	   driver.findElement(By.id("password")).sendKeys("SyedRizwanTesting@gmail.com");
	   Thread.sleep(2000);	  
	}

	@Then("click on Salesforce login")
	public void click_on_salesforce_login() throws InterruptedException 
	{
		driver.findElement(By.id("Login")).click();
			
	}
	
	//Amazon
	@When("Enter the data in seacrh bar")
	public void enter_the_data_in_seacrh_bar() throws Exception {
	    driver.findElement(s_bar).sendKeys("Selenium");
	    Thread.sleep(2000);
	}

	@Then("Click on searchbutton in amazon")
	public void click_on_searchbutton_in_amazon() throws InterruptedException
	{
		driver.findElement(Icon).click();
		Thread.sleep(2000);
		//driver.quit();
	}
	
	@Given("Validate the Mobile button")
	public void validate_the_mobile_button() 
	{
	    driver.findElement(mobile).click();
	}

	@Given("Validate the Sell button")
	public void validate_the_sell_button() 
	{
		driver.findElement(sell).click();
	}
	
	@Then("Close Active window")
	public void close_active_window() {
	    driver.close();
	}
	
	//Scenario Outline
	@Given("^user enter(.*) and (.*)$")
	public void user_enter_and(String username, String password) throws Exception {
	    driver.findElement(By.id("username")).sendKeys(username);
	    Thread.sleep(2000);
	    driver.findElement(By.id("password")).sendKeys(password);
	    Thread.sleep(2000);
	    driver.findElement(By.id("Login")).click();
	}

	
	
	
	
	



}
