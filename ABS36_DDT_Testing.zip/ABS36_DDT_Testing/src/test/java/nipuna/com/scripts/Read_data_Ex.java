package nipuna.com.scripts;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Read_data_Ex {

	public static void main(String[] args) throws Exception 
	{
		//locate the file
		FileInputStream fl= new FileInputStream("C:\\Users\\DELL\\Desktop\\Nipuna.xlsx");
		
		//workbook
		XSSFWorkbook wb =new  XSSFWorkbook(fl);
		
		//locate the sheet            we should update the sheet name of the workbook
		XSSFSheet sheet = wb.getSheet("Sheet1");
		
		//count the row
		int countrow = sheet.getLastRowNum();
		System.out.println("The number of rows are:" + countrow);
		
		//count the cell
		int countcell = sheet.getRow(0).getLastCellNum();
		System.out.println("The number of cells are:" + countcell);
		
		
		
		
	}

}
