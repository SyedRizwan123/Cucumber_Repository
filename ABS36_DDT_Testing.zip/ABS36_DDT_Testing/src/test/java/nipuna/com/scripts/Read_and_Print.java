package nipuna.com.scripts;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Read_and_Print {

	public static void main(String[] args) throws IOException 
	{
		//locate the file
				FileInputStream fl= new FileInputStream("C:\\Users\\DELL\\Desktop\\Nipuna.xlsx");
				
				//workbook
				XSSFWorkbook wb =new  XSSFWorkbook(fl);
				
				//locate the sheet            we should update the sheet name of the workbook
				XSSFSheet sheet = wb.getSheet("Sheet1");
				
				//count the row
				int countrow = sheet.getLastRowNum();
				System.out.println("The number of rows are:" + countrow);
				
				//count the cell
				int countcell = sheet.getRow(0).getLastCellNum();
				System.out.println("The number of cells are:" + countcell);
				
				//Print the data
				for (int i=0; i<countrow;i++)
				{
					XSSFRow count=sheet.getRow(i);
					for (int j=0; j<countcell;j++)
					{
						String data = count.getCell(j).toString();
						System.out.print(" | "+data);
					}
					System.out.println();
				}

	}

}
